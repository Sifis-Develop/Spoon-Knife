package com.fiverr.rest.api.api;

import javax.validation.ConstraintViolationException;

import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fiverr.rest.api.common.exceptions.ErrorResponseBean;
import com.fiverr.rest.api.common.exceptions.SystemErrorCodes;
import com.fiverr.rest.api.common.exceptions.SystemException;

@ControllerAdvice
public class GlobalControllerExceptionHandler {
	
	@ExceptionHandler({ Exception.class })
	public ResponseEntity<ErrorResponseBean> handleException(Exception ex) {
		
		SystemErrorCodes errorCode = null;
		
		if (ex instanceof NoHandlerFoundException)
			errorCode = SystemErrorCodes.NOT_FOUND;
		else if (ex instanceof HttpRequestMethodNotSupportedException
				|| ex instanceof HttpMediaTypeNotSupportedException 
				|| ex instanceof ConstraintViolationException
				|| ex instanceof MethodArgumentNotValidException 
				|| ex instanceof JsonParseException
				|| ex instanceof HttpMessageNotReadableException
				|| ex instanceof MissingServletRequestParameterException
				|| ex instanceof ServletRequestBindingException
				|| ex instanceof MethodArgumentTypeMismatchException)
			errorCode = SystemErrorCodes.BAD_REQUEST;
		else
			errorCode = SystemErrorCodes.INTERNAL_SERVER_ERROR;

		ErrorResponseBean errorResponseBean = new ErrorResponseBean(errorCode.getCode(), errorCode.getMessage());

		return new ResponseEntity<ErrorResponseBean>(errorResponseBean, errorCode.getStatus());
	}

	@ExceptionHandler({ SystemException.class })
	public ResponseEntity<ErrorResponseBean> handleSystemException(SystemException sysEx) {

		ErrorResponseBean errorResponseBean = new ErrorResponseBean(sysEx.getErrorCode().getCode(),
				sysEx.getErrorCode().getMessage());

		return new ResponseEntity<ErrorResponseBean>(errorResponseBean, sysEx.getErrorCode().getStatus());
	}
}
