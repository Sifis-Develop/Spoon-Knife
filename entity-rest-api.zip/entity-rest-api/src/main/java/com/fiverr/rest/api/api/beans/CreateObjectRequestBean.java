package com.fiverr.rest.api.api.beans;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateObjectRequestBean {
	
	@NotBlank
	@Size(min = 1, max = 30)
	private String name;
	
	private String description;
	
}
