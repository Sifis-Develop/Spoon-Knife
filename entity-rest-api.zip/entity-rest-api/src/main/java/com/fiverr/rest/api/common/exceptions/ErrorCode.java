package com.fiverr.rest.api.common.exceptions;

import org.springframework.http.HttpStatus;

public interface ErrorCode {

	Integer getCode();
	
	String getMessage();
	
	HttpStatus getStatus();
}
