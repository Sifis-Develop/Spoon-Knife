package com.fiverr.rest.api.security;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fiverr.rest.api.common.exceptions.ErrorResponseBean;
import com.fiverr.rest.api.common.exceptions.SystemErrorCodes;
import com.fiverr.rest.api.common.exceptions.SystemException;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint{

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {

		SystemException sysEx = SystemException.wrap(authException, SystemErrorCodes.UNAUTHORIZED);

		ErrorResponseBean errorResponseBean = new ErrorResponseBean(sysEx.getErrorCode().getCode(), sysEx.getErrorCode().getMessage());
		String json = new ObjectMapper().writeValueAsString(errorResponseBean);
		response.setStatus(sysEx.getErrorCode().getStatus().value());
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
		response.getWriter().write(json);

	}

}