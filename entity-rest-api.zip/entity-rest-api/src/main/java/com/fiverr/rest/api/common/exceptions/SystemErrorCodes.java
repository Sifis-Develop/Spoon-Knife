package com.fiverr.rest.api.common.exceptions;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SystemErrorCodes implements ErrorCode{
	BAD_REQUEST(400, "Bad request - Validation error", HttpStatus.BAD_REQUEST),
	NOT_FOUND(404, "Not found", HttpStatus.NOT_FOUND),
	INTERNAL_SERVER_ERROR(500, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR),
	UNAUTHORIZED(401, "Unauthorized - Authentication error", HttpStatus.UNAUTHORIZED),
	FORBIDDEN(403, "Forbidden - No access permission", HttpStatus.FORBIDDEN);
	
	private final Integer code;
	private final String message;
	private final HttpStatus status;
	
}

