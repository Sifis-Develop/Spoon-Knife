package com.fiverr.rest.api.services;

import java.util.UUID;

import com.fiverr.rest.api.api.beans.CreateObjectRequestBean;
import com.fiverr.rest.api.api.beans.CreateObjectResponseBean;
import com.fiverr.rest.api.api.beans.GetObjectResponseBean;
import com.fiverr.rest.api.api.beans.UpdateObjectRequestBean;
import com.fiverr.rest.api.common.exceptions.SystemException;

public interface EnityRestApiService {

	public CreateObjectResponseBean insert(CreateObjectRequestBean createObjectRequestBean) throws SystemException;
	
	public GetObjectResponseBean get(UUID publicRefId) throws SystemException;
	
	public GetObjectResponseBean update(UUID publicRefId, UpdateObjectRequestBean updateObjectRequestBean) throws SystemException;
	
	public void delete(UUID publicRefId) throws SystemException;
	
}
