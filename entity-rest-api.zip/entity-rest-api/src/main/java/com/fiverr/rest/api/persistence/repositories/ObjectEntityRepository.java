package com.fiverr.rest.api.persistence.repositories;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fiverr.rest.api.persistence.entities.ObjectEntity;

@Repository
public interface ObjectEntityRepository extends JpaRepository<ObjectEntity, Long> {

	ObjectEntity findByPublicReferenceId(UUID publicReferenceId);
}
