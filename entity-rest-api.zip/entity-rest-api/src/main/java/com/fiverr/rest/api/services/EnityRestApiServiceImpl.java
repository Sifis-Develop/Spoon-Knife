package com.fiverr.rest.api.services;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fiverr.rest.api.api.beans.CreateObjectRequestBean;
import com.fiverr.rest.api.api.beans.CreateObjectResponseBean;
import com.fiverr.rest.api.api.beans.GetObjectResponseBean;
import com.fiverr.rest.api.api.beans.UpdateObjectRequestBean;
import com.fiverr.rest.api.common.exceptions.EnityRestApiErrorCodes;
import com.fiverr.rest.api.common.exceptions.SystemException;
import com.fiverr.rest.api.persistence.entities.ObjectEntity;
import com.fiverr.rest.api.persistence.repositories.ObjectEntityRepository;

@Service
public class EnityRestApiServiceImpl implements EnityRestApiService {
    
    @Autowired
    private ObjectEntityRepository objectEntityRepository;

	@Override
	public CreateObjectResponseBean insert(CreateObjectRequestBean createObjectRequestBean) throws SystemException {
		
		ObjectEntity object = new ObjectEntity();
		object.setPublicReferenceId(UUID.randomUUID());
		object.setName(createObjectRequestBean.getName());
		object.setDescription(createObjectRequestBean.getDescription());
		object.setCreatedAt(LocalDateTime.now());
		
		objectEntityRepository.save(object);
		
		return CreateObjectResponseBean.builder()
				.id(object.getPublicReferenceId().toString())
				.createdAt(object.getCreatedAt())
				.build();

	}

	@Override
	public GetObjectResponseBean get(UUID publicRefId) throws SystemException {
		
		ObjectEntity object = objectEntityRepository.findByPublicReferenceId(publicRefId);
		if(object == null)
			throw new SystemException(EnityRestApiErrorCodes.INVALID_REFERENCE);
		
		return GetObjectResponseBean.builder()
				.name(object.getName())
				.description(object.getDescription())
				.createdAt(object.getCreatedAt())
				.build();
	}

	@Override
	public GetObjectResponseBean update(UUID publicRefId, UpdateObjectRequestBean updateObjectRequestBean) throws SystemException {
		
		ObjectEntity object = objectEntityRepository.findByPublicReferenceId(publicRefId);
		if(object == null)
			throw new SystemException(EnityRestApiErrorCodes.INVALID_REFERENCE);
		
		object.setName(updateObjectRequestBean.getName());
		String description = updateObjectRequestBean.getDescription();
		if(description != null)
			object.setDescription(updateObjectRequestBean.getDescription());
		
		objectEntityRepository.save(object);
		
		return GetObjectResponseBean.builder()
				.name(object.getName())
				.description(object.getDescription())
				.createdAt(object.getCreatedAt())
				.build();
	}

	@Override
	public void delete(UUID publicRefId) throws SystemException {
		
		ObjectEntity object = objectEntityRepository.findByPublicReferenceId(publicRefId);
		if(object == null)
			throw new SystemException(EnityRestApiErrorCodes.INVALID_REFERENCE);
		
		objectEntityRepository.delete(object);
	}

}
