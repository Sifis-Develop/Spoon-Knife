package com.fiverr.rest.api.persistence.entities;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fiverr.rest.api.utilities.LocalDateTimeConverter;

import lombok.Data;

@Entity
@Table(name = "entity_object")
@Data
public class ObjectEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name = "public_reference_id", unique = true, nullable = false)
	private UUID publicReferenceId;
	
	@Column(name="name", length = 30, nullable = false)
	private String name;
	
	@Column(name="description", length = 150)
	private String description;
 
	@Convert(converter = LocalDateTimeConverter.class)
	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt;
	
}
