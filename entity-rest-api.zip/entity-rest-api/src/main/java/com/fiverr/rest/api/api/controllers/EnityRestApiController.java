package com.fiverr.rest.api.api.controllers;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fiverr.rest.api.api.beans.CreateObjectRequestBean;
import com.fiverr.rest.api.api.beans.CreateObjectResponseBean;
import com.fiverr.rest.api.api.beans.GetObjectResponseBean;
import com.fiverr.rest.api.api.beans.UpdateObjectRequestBean;
import com.fiverr.rest.api.common.exceptions.SystemException;
import com.fiverr.rest.api.services.EnityRestApiService;

@RestController
@Validated
@RequestMapping(path="/api/v1/object", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
public class EnityRestApiController {

	@Autowired
	EnityRestApiService enityRestApiService;
	
	@RequestMapping(path = "/create", method = RequestMethod.POST)
	public CreateObjectResponseBean createObject(@RequestBody @Valid CreateObjectRequestBean request) throws SystemException {
	
		return enityRestApiService.insert(request);
	}
	
	@RequestMapping(path = "/{objectId}", method = RequestMethod.GET)
	public GetObjectResponseBean get(@PathVariable(value = "objectId") @NotNull UUID objectPublicRefId) throws Exception {

		return enityRestApiService.get(objectPublicRefId);
	}
	
	@RequestMapping(path = "/{objectId}", method = RequestMethod.PUT)
	public GetObjectResponseBean update(@PathVariable(value = "objectId") @NotNull UUID objectPublicRefId,
			@RequestBody @Valid UpdateObjectRequestBean request) throws Exception {

		return enityRestApiService.update(objectPublicRefId, request);
	}
	
	@RequestMapping(path = "/{objectId}", method = RequestMethod.DELETE)
	public void update(@PathVariable(value = "objectId") @NotNull UUID objectPublicRefId) throws Exception {

		enityRestApiService.delete(objectPublicRefId);
	}
	
}
