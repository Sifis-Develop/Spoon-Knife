package com.fiverr.rest.api.common.exceptions;

import java.io.PrintWriter;
import java.util.Map;
import java.util.TreeMap;

public class SystemException extends RuntimeException{

	private static final long serialVersionUID = 1L;

    private ErrorCode errorCode;

    private final Map<String, Object> properties = new TreeMap<>();

    public SystemException(ErrorCode errorCode)
    {
        super(errorCode.getMessage());

        this.errorCode = errorCode;
    }
    

    /**
     * Constructor
     *
     * @param errorCode the ErrorCode object with error details
     * @param cause     the Java Throwable (Error or Exception) that is associated with this SystemException
     * @param message   the error message that will overwrite the default message from the ErrorCode object
     */
    public SystemException(String message, Throwable cause, ErrorCode errorCode)
    {
        super(message, cause);

        this.errorCode = errorCode;
    }


    /**
     * Factory style static constructor
     *
     * @param exception the Java Throwable (Error or Exception) that is associated with this SystemException
     * @param errorCode the ErrorCode object with error details
     * @return the newly created SystemException, initialized with all required fields
     */
    public static SystemException wrap(Throwable exception, ErrorCode errorCode)
    {
        if (exception instanceof SystemException)
        {
            SystemException se = (SystemException) exception;

            if (errorCode != null && errorCode != se.getErrorCode())
                return new SystemException(exception.getMessage(), exception, errorCode);
            else
                return se;
        }
        else
        {
            return new SystemException(exception.getMessage(), exception, errorCode);
        }
    }

    /**
     * Factory style static constructor
     * used for null/default ErrorCode
     *
     * @param exception the Java Throwable (Error or Exception) that is associated with this SystemException
     * @return the newly created SystemException, initialized with all required fields
     */
    public static SystemException wrap(Throwable exception)
    {
        return wrap(exception, null);
    }


    /**
     * Retrieve the ErrorCode of the SystemException
     *
     * @return the ErrorCode of the SystemException
     */
    public ErrorCode getErrorCode()
    {
        return errorCode;
    }

    /**
     * Set the ErrorCode of the SystemException
     *
     * @param errorCode the error code to set
     * @return the updated SystemException
     */
    public SystemException setErrorCode(ErrorCode errorCode)
    {
        this.errorCode = errorCode;

        return this;
    }

    /**
     * Retrieve the properties map of the exception
     *
     * @return the Map of the properties
     */
    public Map<String, Object> getProperties()
    {
        return properties;
    }

	/**
     * Retrieve a specific property, based on its name
     *
     * @param name the name of the property to get
     * @param <T>  the type of the property used
     * @return the value of the property in the requested type
     */
    @SuppressWarnings("unchecked")
    public <T> T get(String name)
    {
        return (T) properties.get(name);
    }

    /**
     * Set the value of a specific property, based on its name
     *
     * @param name  the name of the property to set
     * @param value the value of the property to set
     * @return the updated SystemException with all properties set
     */
    public SystemException set(String name, Object value)
    {
    	properties.put(name, value);
        
    	return this;
    }

    public String getSerializedProperties()
    {
    	String serializedProperties = "";
    	
        for (String key : properties.keySet())
        {
    		serializedProperties += key + "=" + properties.get(key) + " | ";
        }
        
        if(!serializedProperties.isEmpty())
        	serializedProperties = serializedProperties.substring(0, serializedProperties.length()-3);
        else
        	serializedProperties = "None";
        
        return serializedProperties;    	
    }


    /**
     * Print the exception stack trace, while first appending any internal SystemException properties used
     *
     * @param s PrintWriter to output the stack trace text
     */
    @Override
    public void printStackTrace(PrintWriter s)
    {
        synchronized (s)
        {

            s.println(this);
            s.println("\t-------------------------------");

            if (errorCode != null)
            {
                s.println("\t" + errorCode + ":" + errorCode.getClass().getName());
            }
            for (String key : properties.keySet())
            {
        		s.println("\t" + key + "=[" + properties.get(key) + "]");
            }
            s.println("\t-------------------------------");

            StackTraceElement[] trace = getStackTrace();
            for (int i = 0; i < trace.length; i++)
                s.println("\tat " + trace[i]);

            Throwable ourCause = getCause();
            if (ourCause != null)
            {
                ourCause.printStackTrace(s);
            }
            s.flush();
        }
    }
	
}