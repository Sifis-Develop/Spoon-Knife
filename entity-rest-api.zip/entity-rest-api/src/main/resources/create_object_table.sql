CREATE TABLE public.entity_object (
	id int8 NOT NULL,
	public_reference_id uuid NOT NULL,
	name varchar(30) NULL,
	description varchar(150) NULL,
	created_at timestamp NOT null,
	CONSTRAINT entity_object_pkey PRIMARY KEY (id),
	CONSTRAINT entity_object_public_reference_id_key UNIQUE (public_reference_id)
);